function promo() 
{
alert("A técninca sendo usada no JavaScript desta página é 'getElementById' para mostrar o preço à vista e parcelado");
}